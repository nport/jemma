Too many differences with 3.3.0, also in components definition. Removed old classes/components
