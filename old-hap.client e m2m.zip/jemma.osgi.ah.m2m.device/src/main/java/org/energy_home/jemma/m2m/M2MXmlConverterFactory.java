package org.energy_home.jemma.m2m;

public class M2MXmlConverterFactory {

	private static M2MXmlConverter connectionInstance = null;
	private static M2MXmlConverter coreInstance = null;

	public synchronized static M2MXmlConverter getConnectionConverter() {
		if (connectionInstance == null)
			connectionInstance = new M2MXmlConverterJaxb(M2MXmlConverterJaxb.JAXB_CONNECTION_CONTEXT_PATH,
					M2MXmlConverterJaxb.JAXB_CONNECTION_NAMESPACE, null, 1);
		return connectionInstance;
	}

	public synchronized static M2MXmlConverter getCoreConverter() {
		if (coreInstance == null) {
			coreInstance = new M2MXmlConverterJaxb(M2MXmlConverterJaxb.JAXB_CORE_CONTEXT_PATH,
					M2MXmlConverterJaxb.JAXB_CORE_NAMESPACE, M2MXmlConverterJaxb.JAXB_CORE_NAMESPACES_PREFERRED_PREFIX_MAP, 1);
		}
		return coreInstance;
	}
}
