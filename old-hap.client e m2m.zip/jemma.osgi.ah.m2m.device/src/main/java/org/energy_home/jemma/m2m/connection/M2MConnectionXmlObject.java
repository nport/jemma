/**
 * This file is part of JEMMA - http://jemma.energy-home.org
 * (C) Copyright 2013 Telecom Italia (http://www.telecomitalia.it)
 *
 * JEMMA is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License (LGPL) version 3
 * or later as published by the Free Software Foundation, which accompanies
 * this distribution and is available at http://www.gnu.org/licenses/lgpl.html
 *
 * JEMMA is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License (LGPL) for more details.
 *
 */
package org.energy_home.jemma.m2m.connection;


import java.io.InputStream;
import java.io.OutputStream;

import org.energy_home.jemma.m2m.M2MXmlConverter;
import org.energy_home.jemma.m2m.M2MXmlConverterFactory;

public class M2MConnectionXmlObject implements Cloneable {

	private static M2MXmlConverter converter =  M2MXmlConverterFactory.getConnectionConverter();
	
	public static byte[] getByteArray(Object o) {
		return converter.getByteArray(o);
	}

	public static String getString(Object o) {
		return converter.getString(o);
	}

	public static String getPrintableString(Object o) {
		return converter.getPrintableString(o);
	}

	public static String getFormattedString(Object o) {
		return converter.getFormattedString(o);
	}

	public static M2MConnectionXmlObject getObject(String xmlString) {
		return (M2MConnectionXmlObject) converter.getObject(xmlString);
	}

	public static M2MConnectionXmlObject readObject(InputStream in) {
		return (M2MConnectionXmlObject) converter.readObject(in);
	}

	public static void writeObject(Object object, OutputStream out) {
		converter.writeObject(object, out);
	}

	public static M2MConnectionXmlObject loadFromFile(String filePath) {
		return (M2MConnectionXmlObject) converter.loadFromFile(filePath);
	}

	public static boolean saveToFile(String filePath, Object object) {
		return converter.saveToFile(filePath, object);
	}

	public Object clone() throws CloneNotSupportedException {
		return converter.getObject(this.toXmlString());
	}

	public String toXmlString() {
		return converter.getString(this);
	}

	public String toXmlPrintableString() {
		return converter.getPrintableString(this);
	}

	public String toXmlFormattedString() {
		return converter.getFormattedString(this);
	}

}
