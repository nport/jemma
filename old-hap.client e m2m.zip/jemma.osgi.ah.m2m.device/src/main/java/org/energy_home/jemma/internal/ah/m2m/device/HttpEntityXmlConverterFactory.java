package org.energy_home.jemma.internal.ah.m2m.device;

import org.energy_home.jemma.m2m.M2MXmlConverterJaxb;

public class HttpEntityXmlConverterFactory {

	private static HttpEntityXmlConverterJaxb connectionInstance = null;
	private static HttpEntityXmlConverterJaxb coreInstance = null;

	public synchronized static HttpEntityXmlConverter getConnectionConverter() {
		if (connectionInstance == null)
			connectionInstance = new HttpEntityXmlConverterJaxb(M2MXmlConverterJaxb.JAXB_CONNECTION_CONTEXT_PATH,
					M2MXmlConverterJaxb.JAXB_CONNECTION_NAMESPACE, null, 1);
		return connectionInstance;
	}

	public synchronized static HttpEntityXmlConverter getCoreConverter() {
		if (coreInstance == null) {
			coreInstance = new HttpEntityXmlConverterJaxb(M2MXmlConverterJaxb.JAXB_CORE_CONTEXT_PATH,
					M2MXmlConverterJaxb.JAXB_CORE_NAMESPACE, M2MXmlConverterJaxb.JAXB_CORE_NAMESPACES_PREFERRED_PREFIX_MAP, 1);
		}
		return coreInstance;
	}
}
