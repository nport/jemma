M2M Device
==========

Exposes stateless XML Rest API to send data and to perform queries.